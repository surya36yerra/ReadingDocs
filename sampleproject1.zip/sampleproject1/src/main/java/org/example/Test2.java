//import java.util.*;
//
//public class Test2 {
//
//    public static void main(String[] args) {
//        getVowels();
//    }
//
//
//}
//
//    static void getVowels() {
//        String s = "lEetcOde";
//        char[] c = s.toCharArray();
//        List<Character> list = Arrays.asList('a', 'e', 'i', 'o', 'u');
//        List<Character> vList = new ArrayList<>();
//
//        Map<Character, Integer> myMap = new HashMap<>();
//        for (char c1 : c) {
//            if (list.contains(Character.toLowerCase(c1))) {
//                vList.add(c1);
//            }
//        }
//
//        //c = l,E,e,t,c,o,d,e
//        //vlist  = o,e,e
//        for (Character c2 : vList) {
//           Collections.sort(vList);
//        }
//
//        for(int i=0;i<c.length;i++){
//            StringBuilder sb = new StringBuilder();
//            if(list.contains(Character.toLowerCase(c[i]))) {
//               char temp = vList.get(0);
//               vList.get(0) = c[i];
//                c[i] = temp;
//            }
//            else {
//                sb.append(c[i]);
//            }
//        }
//
//
//        System.out.println(myMap);
//    }
//
//public void main() {
//}
