//package org.example;
//
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.Map;
//import java.util.concurrent.*;
//
//import static sun.swing.SwingUtilities2.submit;
//
//public class Test1
//{
//
//    Map<String,Integer> doComputaion(Map<String, Callable<Integer>> task) throws ExecutionException, InterruptedException {
//
//        ExecutorService ex = Executors.newFixedThreadPool(10);
//
//
//       // Using a lambda expression to implement the submit method{
//  Map<String,Future<Integer>> myMap = new HashMap<String, Future<Integer>>();
//
//        // Using a lambda expression to implement the submit method
//        // Using parallelStream to process the task map concurrently
//
//  for (Map.Entry<String, Callable<Integer>> entry : task.entrySet().parallelStream()) {
//              Future<Integer> future =   ex.submit(task.get(entry.getKey()));
//              CompletableFuture<Integer> future2 = ex.submit(task.getKey());
//              myMap.put(entry.getKey(), future.get());
//        }
//        return myMap;
//        };
//
//    }
//
//}
